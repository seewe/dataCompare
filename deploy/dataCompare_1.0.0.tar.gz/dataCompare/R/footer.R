footer <- function() {
  dashboardFooter(
    left = tags$text("(c), 2024"), 
    right = tags$text("data4know")
    )
}
